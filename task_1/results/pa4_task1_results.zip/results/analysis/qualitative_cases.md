HellaSwag manifest unavailable: manifest not found: data/public_locked/hellaswag_val_locked.jsonl.gz
